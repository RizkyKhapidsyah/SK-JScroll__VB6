Project Analyzer 
with library files

Installation
============

1. Install VB 6.0 library files. Unzip the DLL package ProA_VB60DLLs.zip
to an empty directory, and run setup.exe. If the installation requires a
reboot, continue the installation by running continue.exe.

2. Install program files. Unzip the EXE package proa5???.zip to an empty 
directory and run project.exe. No setup program needed for this.

3. If you get library problems, check that you ran continue.exe in 
step 1 above.


Aivosto Oy
www.aivosto.com
vbshop@aivosto.com

